% This function reproduces the results in the paper using a pre-trained
% MLP model from a specific configuration of experiment type (A and B), 
% texture feature averaging (yes and no), and ranklet resolution 
% (0, 2, 4, and 8).

clearvars; close all; clc;

addpath(fullfile(pwd,'utils'));

% Experiment type: 1 (Pre- and post-contrast sequences) 
% or 2 (also include subtraction sequences)
e = 2;   

% Optionally, texture features can be averaged over the 13 directions
% to reduce dimensionality
avg = false; % false - non-averaged, true - averaged

% Ranklet resolution: 2, 4, or 8. If r = 0, uses gray-level data
r = 4; 

% Load data
if r > 0 % Ranklet features
    pathIn = fullfile(pwd,'Features',sprintf('R%d',r));
    co = [4212 7956]; % Cut-off for experiments A and B
    if avg
        pathMd = fullfile(pwd,'MLPs\avg',sprintf('R%d',r),sprintf('exp%d.mat',e));
    else
        pathMd = fullfile(pwd,'MLPs\non_avg',sprintf('R%d',r),sprintf('exp%d.mat',e));
    end
else % Gray-level features
    pathIn = fullfile(pwd,'Features','GL');
    co = [702 1326]; % Cut-off for experiments A and B
    if avg
        pathMd = fullfile(pwd,'MLPs\avg\GL',sprintf('exp%d.mat',e));
    else
        pathMd = fullfile(pwd,'MLPs\non_avg\GL',sprintf('exp%d.mat',e));
    end
end
load(pathMd) % Load trained model

% Load test set
tt  = load(fullfile(pathIn,'test.mat'));
Xtt = tt.X(:,1:co(e));
Ytt = tt.Y;
if avg
    Xtt = glcm_feats_average(Xtt,tt.id(1:co(e)));
end

% Feature ranking
Xtt = Xtt(:,idx);

% Select the m-best ranked features
Xtt = Xtt(:,1:hpar.ft);

% Normalize with z-score
Xtt = zscorenorm(Xtt,stats); 

% Classify with MLP
[Ypp,P] = classify(net,Xtt); 

% Classification performance
[Out,C] = binclassperf(Ytt,Ypp=='1',P); 

% Results
cm = confusionchart(C,["Malignant";"Benign"]);
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
cm.Title = 'Confusion Matrix';

fprintf("Experiment: %d | Averaged: %d | Ranklet resolution: %d\n",e,avg,r);
fprintf("Accuracy: %0.3f\n",Out(1));
fprintf("Precision: %0.3f\n",Out(3));
fprintf("Sensitivity: %0.3f\n",Out(4));
fprintf("Specificity: %0.3f\n",Out(5));
fprintf("BAC: %0.3f\n",Out(7));
fprintf("AUC: %0.3f\n",Out(8));