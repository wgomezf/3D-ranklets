% This function performs a training-test experiment given a specific
% configuration of experiment type (A and B), texture feature averaging 
% (yes and no), and ranklet resolution (0, 2, 4, and 8). The 
% hyperparameters of an MLP model are tuned via Bayesian optimization, and
% the optimal model is evaluated on the test set.

clearvars; close all; clc;

addpath(fullfile(pwd,'utils'));

% Experiment type: 1 (Pre- and post-contrast sequences) 
% or 2 (also include subtraction sequences)
e = 2;   

% Optionally, texture features can be averaged over the 13 directions
% to reduce dimensionality
avg = false; % false - non-averaged, true - averaged

% Ranklet resolution: 2, 4, or 8. If r = 0, uses original gray-level data
r = 4; 

% Load data
if r > 0
    pathIn = fullfile(pwd,'Features',sprintf('R%d',r));
    co = [4212 7956]; % Cut-off for experiments
else
    pathIn = fullfile(pwd,'Features','GL');
    co = [702 1326]; % Cut-off for experiments
end

% Split data into training, validation, and test sets already defined in the
% BreastDM dataset
% Training set
tr  = load(fullfile(pathIn,'train.mat'));
Xtr = tr.X(:,1:co(e)); % Features
Ytr = tr.Y; % Class labels
if avg
    Xtr = glcm_feats_average(Xtr,tr.id(1:co(e)));
end
% Validation set
vd  = load(fullfile(pathIn,'val.mat'));
Xvd = vd.X(:,1:co(e));
Yvd = vd.Y;
if avg
    Xvd = glcm_feats_average(Xvd,vd.id(1:co(e)));
end
% Test set
tt  = load(fullfile(pathIn,'test.mat'));
Xtt = tt.X(:,1:co(e));
Ytt = tt.Y;
if avg
    Xtt = glcm_feats_average(Xtt,tt.id(1:co(e)));
end

% Feature ranking with MRMR
Dtr = CAIMe([Xtr Ytr],0); % Convert to discrete features (only training set)
[idx,scr] = fscmrmr(Dtr,Ytr,'CategoricalPredictors','all'); % MRMR with mutual information
Xtr = Xtr(:,idx); % Rank features
Xvd = Xvd(:,idx);
Xtt = Xtt(:,idx);

% Train an MLP tuned by Bayesian optimization
[net,stats,hpar,info] = mlp_bayesopt(Xtr,Ytr,Xvd,Yvd);

% Evaluate classification performance on test set
Xtt = Xtt(:,1:hpar.ft);         % Select the m-best ranked features
Xtt = zscorenorm(Xtt,stats);    % Normalize with z-score
[Ypp,P] = classify(net,Xtt);    % Classify with MLP
[Out,C] = binclassperf(Ytt,Ypp=='1',P); % Classification performance