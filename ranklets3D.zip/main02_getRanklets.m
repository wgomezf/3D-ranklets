% This function takes a DCE-MRI case from the BreastDM saved in an 
% MAT file and computes the 3-D ranklet transform, followed by 
% GLCM-based feature extraction. 

clearvars; close all; clc;

addpath(fullfile(pwd,'utils'));

% Ranklet and GLCM parameters
r = 4; % Ranklet resolution
d = 1; % GLCM distance
Q = 8; % GLCM quantization levels

% Variable names in MAT file: C0 is pre-contrast, C1 to C8 are post-contrast,
% and SUB1 to SUB7 are subtraction sequences
varnames = {'C0' 'C1' 'C2' 'C3' 'C4' 'C5' 'C6' 'C7' 'C8'...
            'SUB1' 'SUB2' 'SUB3' 'SUB4' 'SUB5' 'SUB6' 'SUB7' 'SUB8'};

% For each sequence: 13 GLCM directions by six texture features
[~,id1] = meshgrid(1:78,1:numel(varnames)); % Position indices to save gray-level features
id1 = reshape(id1',1,78*numel(varnames));
% For each sequence: six ranklet orientations by 13 GLCM directions by six texture features
[~,id2] = meshgrid(1:468,1:numel(varnames)); % Position indices to save ranklet features 
id2 = reshape(id2',1,468*numel(varnames)); 

% Case name save in a MAT file
fileName = 'BreaDM-Ma-1802.mat';

% Initialize texture feature vectors
Xgl = zeros(1,numel(id1)); % For gray-level
Xrk = zeros(1,numel(id2)); % For ranklets
for i = 1:numel(varnames)
    load(fileName);
    eval(sprintf('I=%s.Image;',varnames{i})); % Gray-level data
    % Compute the 3-D ranklet transform
    R = ranklets3d(I,r);
    % Compute GLCMs from the original gray-level image in the range [0,255]
    CMgl = getGLCMs(I,d,[0 255],Q);
    % Compute texture features and put them in a vector
    Xgl(1,id1==i) = glcm_feats(CMgl);
    % Compute GLCMs from the ranklet images in the range [-1,1]
    CMrk = getGLCMs(R,d,[-1 1],Q);
    % Compute texture features and put them in a vector
    Xrk(1,id2==i) = glcm_feats(CMrk);
end

% Finally, put this feature vector (Xgl or Xrk) into a table with the 
% remaining breast DCE-MRI cases, and remember to include the class label.

i = randi([1 6],1,1);  % Randomly selects a ranklet direction
j = randi([1 13],1,1); % Randomly selects a GLCM direction
volshow(R(:,:,:,i),'OverlayData',SUB8.Mask); % Shows a ranklet image
figure; imagesc(CMrk(:,:,j,i)); % Shows a GLCM
