% MLP's hyperparameter tuning by Bayesian optimization
%   Inputs:
%       Xtr - Training data
%       Ytr - Training class labels
%       Xvd - Validation data
%       Yvd - Validation class labels
%   Outputs:
%       net - MLP trained model
%       stats - Statistics of mean and standard deviation for 
%               z-score normalization
%       hpar - Optimal hyperparameters
%       info - MLP learning curves

function [net,stats,hpar,info] = mlp_bayesopt(Xtr0,Ytr0,Xvd0,Yvd0)

% Data normalization
[Xtr,stats] = zscorenorm(Xtr0);
Xvd = zscorenorm(Xvd0,stats);
Ytr = categorical(Ytr0);
Yvd = categorical(Yvd0);

% Hyperparameters to tune
D = size(Xtr,2);
ft = optimizableVariable('ft',[1,D],'Type','integer');      % Cut-off point to select best ranked features
hn = optimizableVariable('hn',[2^1,2^12],'Type','integer'); % Number of hidden neurons
lr = optimizableVariable('lr',[1e-4,1e-2],'Type','real');   % Learning rate
mc = optimizableVariable('mc',[0.01,0.99],'Type','real');   % Momentum factor

% Bayesian optimization
fun = @(x)MLPeval(Xtr,Ytr,Xvd,Yvd,x.ft,x.hn,x.lr,x.mc);
results = bayesopt(fun,[ft,hn,lr,mc],'Verbose',0,...
    'AcquisitionFunctionName','expected-improvement-per-second-plus',...
    'PlotFcn',[],'GPActiveSetSize',1000,'MaxObjectiveEvaluations',100);

% Get optimal hyperparameters
pars = table2array(results.XAtMinObjective);
hpar.ft = pars(1);
hpar.hn = pars(2);
hpar.lr = pars(3);
hpar.mc = pars(4);

% Train final MLP model using the optimal hyperparameters
XX  = [Xtr0;Xvd0]; % Fuse training and validation sets
Ytr = categorical([Ytr0;Yvd0]);
XX  = XX(:,1:hpar.ft); % Select m-best ranked features
[Xtr,stats] = zscorenorm(XX); % Normalization with z-score
[mlp,opt] = config(Xtr,Ytr,[],[],hpar.hn,hpar.lr,hpar.mc);
[net,info] = trainNetwork(Xtr,Ytr,mlp,opt); % Train MLP

%*********************************************************
function [err,net] = MLPeval(Xtr,Ytr,Xvd,Yvd,ft,hn,lr,mc)
Xtr = Xtr(:,1:ft);
Xvd = Xvd(:,1:ft);
[mlp,opt] = config(Xtr,Ytr,Xvd,Yvd,hn,lr,mc);
[net,~] = trainNetwork(Xtr,Ytr,mlp,opt);
[Ypp,P] = classify(net,Xvd);
out = binclassperf(Yvd=='1',Ypp=='1',P);
acc = out(7); % Cost function: balanced accuracy
err = 1-acc;  % "bayesopt" minimizes the cost function
fprintf('MLP - Features: %d, Hidden nodes: %d - Learning rate: %0.3e - Momentum: %0.3f - BAC: %0.3f\n',ft,hn,lr,mc,acc);

%*********************************************************
function [mlp,opt] = config(Xtr,Ytr,Xvd,Yvd,hn,lr,mc)

mB = 16;
valFreq = floor(numel(Ytr)/mB);

if isempty(Xvd)
    VD = [];
    opt = "last-iteration";
else
    VD = {Xvd,Yvd};
    opt = "best-validation";
end

opt = trainingOptions("sgdm","Plots","none",...
                      "MaxEpochs",30,...
                      "MiniBatchSize",mB,...
                      "InitialLearnRate",lr,...
                      "Momentum",mc,...
                      "L2Regularization",1e-4,...
                      "ExecutionEnvironment","gpu",...
                      "Shuffle","every-epoch",...
                      "ValidationFrequency",valFreq,...
                      "ValidationData",VD,...
                      "OutputNetwork",opt,...
                      "Verbose",0);

% MLP architecture with one hidden layer
mlp = [featureInputLayer(size(Xtr,2),"Name","input")
       fullyConnectedLayer(hn,"Name","fc1")
       reluLayer("Name","act1")
       dropoutLayer("Name","drop1")
       fullyConnectedLayer(2,"Name","fc2")
       softmaxLayer("Name","softmax")
       classificationLayer("Name","output")];