% Calculate the 13 GLCMs for all ranklet images (six directions).
function CM = getGLCMs(I,d,L,Q)
I = double(I);
nr = size(I,4);
CM = zeros(Q,Q,13,nr);
for i = 1:nr
    CM(:,:,:,i) = glcm3d(I(:,:,:,i),d,L,Q);
end