function Vnew = isotropic_resampling(V,pixelW,sliceS,scale)
if islogical(V)
    ntype = "nearest";
else
    ntype = "cubic";
end
a = pixelW/scale;
b = pixelW/scale;
c = sliceS/scale;
[M,N,K] = size(V);
tsize = round([M*a N*b K*c]);
scale = tsize./size(V);
% Make transformation structure   
T = makehgtform('scale',scale);
tform = maketform('affine', T);
% Specify resampler
R = makeresampler(ntype,"fill");
% Resize the image volume
Vnew = tformarray(V, tform, R, [1 2 3], [1 2 3], tsize, [], 0);
