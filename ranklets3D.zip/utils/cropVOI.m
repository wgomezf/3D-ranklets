% Crop a volume of interest (VOI) using the segmentation mask
% to identify the bounding box
% Variables:
%   I  - Gray-level volume
%   BW - Segmentation mask

function [I,BW] = cropVOI(I,BW)
BW = BW==1;
% Ensure a single region in the segmentation mask
% corresponding to the tumor
V = regionprops3(BW,'Volume');
V = cat(1,V.Volume);
if numel(V) > 1
    BW = bwareaopen(BW,max(V));
end
% Identify the extreme coordinates of the bounding box
[~,C] = bbox(BW);
% Crop the VOI
I  = imcrop3(I,C);
BW = imcrop3(BW,C);
%************************************************************************
function [M,C] = bbox(BW)
[M,N,K] = size(BW);
C = regionprops3(BW,'BoundingBox');
w = C.BoundingBox(4);
h = C.BoundingBox(5);
d = C.BoundingBox(6);
xmn = max(1,round(C.BoundingBox(1)));
xmx = min(N,round(C.BoundingBox(1)+w));
ymn = max(1,round(C.BoundingBox(2)));
ymx = min(M,round(C.BoundingBox(2)+h));
zmn = max(1,round(C.BoundingBox(3)));
zmx = min(K,round(C.BoundingBox(3)+d));
M   = false(M,N,K);
M(ymn:ymx,xmn:xmx,zmn:zmx) = true;
C = [xmn ymn zmn xmx-xmn ymx-ymn zmx-zmn];