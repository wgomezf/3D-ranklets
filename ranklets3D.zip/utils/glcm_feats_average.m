% Average texture features to reduce dimensionality.
function X2 = glcm_feats_average(X,id)
N = size(X,1);
if any(numel(id)==[4212 7956])
    R = 6; % Number of ranklet orientations
elseif any(numel(id)==[702 1326])
    R = 1; % Single gray-scale image
end
X2 = zeros(N,6*R*max(id));
for a = 1:N
    x = [];
    for b = 1:max(id)
        aux = feat_reduce(X(a,id==b),R);
        x = cat(2,x,aux);
    end
    X2(a,:) = x;
end
%************************************************************************
function x = feat_reduce(x,R)
M = 13; % Number of GLCM matrices
x = reshape(x,M*R,6);
x = reshape(x',6,M,R);
res = mean(x,2);
x = reshape(res,6,R);
x = reshape(x',1,6*R);