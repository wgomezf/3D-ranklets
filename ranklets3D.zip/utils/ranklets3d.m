% Compute the 3-D ranklet transform of volume "I" using a resolution "r" 
% and six orientations.
function R = ranklets3d(I,r)
if not(ceil(log2(r)) == floor(log2(r)))
    error('The ranklet resolution must be power of two.');
end
I = double(I);
[M,N,K] = size(I);
J = padarray(I,[r r r]/2,"symmetric","both");
masks = ranklet_masks(r);
R = zeros(M,N,K,6);
% PARFOR requires Parallel Computing Toolbox to accelerate the
% ranklet computation. If it is not available, use a simple FOR
parfor l = 1:size(masks,2)
    R(:,:,:,l) = ranklets(J,masks,l,M,N,K,r);
end
%********************************************************************
function aux = ranklets(VOI,msk,l,M,N,K,r)
rows = 0:(r-1);
cols = 0:(r-1);
depths = 0:(r-1);
n  = r*r*r;
c1 = (n/4)*((n/2)+1);
c2 = (n*n)/8;
h  = msk(:,l);
aux = zeros(M,N,K);
for i = 1:M
    for j = 1:N
        for k = 1:K
            L = VOI(i+rows,j+cols,k+depths);
            rnk = tiedrank(L(:));
            aux(i,j,k) = (sum(rnk(h)) - c1)/c2 - 1;
        end
    end
end
%********************************************************************
function hs = ranklet_masks(r)
hdd = @(a,b)((a&b)|((~a)&(~b)));
p  = true(r,r);
hx = false(r,r,r);
hy = false(r,r,r);
hz = false(r,r,r);
for i = 1:r/2
    hy(i,:,:) = p;
    hx(:,i,:) = p;
    hz(:,:,i) = p;
end
hxy = hdd(hx,hy);
hyz = hdd(hy,hz);
hxz = hdd(hx,hz);
hs  = [hx(:) hy(:) hz(:) hxy(:) hxz(:) hyz(:)];