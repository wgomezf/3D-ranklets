% Compute six GLCM-based texture features:
%   1. Joint Energy 
%   2. Joint Entropy
%   3. Correlation
%   4. Contrast
%   5. Dissimilarity
%   6. Homogeneity

function feats = glcm_feats(CMs)
[Q,~,M,R] = size(CMs);
[i,j] = meshgrid(1:Q,1:Q);
feats = zeros(6,M,R);
for r = 1:R
    feats_ = zeros(6,M);
    for m = 1:M
        % Normalize GLCM
        CM  = CMs(:,:,m,r);
        N = sum(CM,'all');
        if N > 0 % Non-empty GLCM
            Pij = CM./N;
            % Means
            u_x = sum(sum(i.*Pij));
            u_y = sum(sum(j.*Pij));
            % Variances
            s_x = sum(sum(Pij.*((i-u_x).^2)))^0.5;
            s_y = sum(sum(Pij.*((j-u_y).^2)))^0.5;
            % Features
            feats_(1,m) = sum(Pij.^2,'all'); % Joint Energy (the same as Angular Second Moment)
            feats_(2,m) = -sum(Pij.*log2(Pij+eps),'all'); % Joint Entropy
            feats_(3,m) = sum((Pij.*(i-u_x).*(j-u_y))/(s_x*s_y+eps),'all'); % Correlation
            feats_(4,m) = sum(((i-j).^2).*Pij,'all'); % Contrast
            feats_(5,m) = sum(abs(i-j).*Pij,'all'); % Dissimilarity (the same as Difference Average)
            feats_(6,m) = sum(Pij./(1+abs(i-j)),'all'); % Homogeneity (the same as Inverse Difference)
        end
    end
    feats(:,:,r) = feats_;
end
feats = reshape(feats,6,M*R);
feats = reshape(feats',1,6*M*R);