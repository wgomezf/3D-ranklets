% Compute the 3-D GLCM
% Variables:
%   I - Input volume
%   d - Distance between voxels
%   L - Original gray-level range in the volume
%   Q - Number of levels for quantization
%   G - GLCMs

function G = glcm3d(I,d,L,Q)
% Quantize image
I = imquant(I,L,Q);
% 13 directions (DOI 10.1109/TMI.2019.2963177)
O = d*[-1 -1 1;-1 0 1;-1 1 1;0 -1 1;0 0 1;0 1 1;1 -1 1;1 0 1;1 1 1;0 1 0;1 -1 0;1 0 0;1 1 0];
[x,y,z] = meshgrid(-d:d);
no = size(O,1);
G = zeros(Q,Q,no); % GLCM matrices
for i = 1:no
    % Copy voxel J in a specific orientation to the location
    % of the voxel I
    k = double((x == O(i,1)) & (y == O(i,2)) & (z == O(i,3)));
    J = imfilter(I,k,'same','corr');
    p = [I(:) J(:)]; % voxel i vs. j
    % Eliminate border voxel counts (0-valued) and NaN voxels
    id = logical(sum(p==0,2)) | logical(sum(isnan(p),2));
    p(id,:) = [];
    % Count ocurrencies
    G_ = accumarray(p,1,[Q Q]); % Counts
    % Discretization length correction
    G(:,:,i) = G_*sqrt(sum(abs(O(i,:))));     
end
%***********************************************************
function I = imquant(I,L,Q)
I = double(I);
if isempty(L)
    L = [min(I(:)) max(I(:))];
end
slope = (Q-1) / (L(2) - L(1));
intercept = 1 - (slope*(L(1)));
I = round(imlincomb(slope,I,intercept,'double'));