% z-score normalization
function [DV,stats] = zscorenorm(F,stats)
if nargin == 1
    m = mean(F,1);
    s = std(F,[],1);
    stats = [m;s];
elseif nargin == 2
    m = stats(1,:);
    s = stats(2,:);
end
FM = bsxfun(@minus,F,m);
DV = bsxfun(@rdivide,FM,s);