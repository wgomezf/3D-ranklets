% This function reconstructs 3-D images of DCE-MRI gray-level data 
% and its corresponding binary segmentation mask taken from the 
% BreastDM dataset. One pre-contrast sequence, eight post-contrast 
% sequences, and eight subtraction sequences are considered. The 
% volumes are saved in a MAT file for further processing.

clearvars; close all; clc;

addpath(fullfile(pwd,'utils'));

% BreastDM path
pathIn = fullfile(pwd,'BreaDM\seg\');

% Path to save MAT file
pathOut = pwd; % Put here your path

% Folders inside 'images' and 'labels'
% pre-contrast, post-contrast,and subtraction sequences
types = {'SUB1' 'SUB2' 'SUB3' 'SUB4' 'SUB5' 'SUB6' 'SUB7' 'SUB8'...
         'VIBRANT' 'VIBRANT+C1' 'VIBRANT+C2' 'VIBRANT+C3' 'VIBRANT+C4'...
         'VIBRANT+C5' 'VIBRANT+C6' 'VIBRANT+C7' 'VIBRANT+C8'};

% Output variables: C0 is pre-contrast, C1 to C8 are post-contrast,
% and SUB1 to SUB7 are subtraction sequences
varnames = {'SUB1' 'SUB2' 'SUB3' 'SUB4' 'SUB5' 'SUB6' 'SUB7' 'SUB8'...
            'C0' 'C1' 'C2' 'C3' 'C4' 'C5' 'C6' 'C7' 'C8'};

% Case name
fileName = 'BreaDM-Ma-1802';

for i = 1:numel(types)
    % Get the full-path to a specific case
    strI = fullfile(pathIn,'train/images',fileName,types{i});
    strM = fullfile(pathIn,'train/labels',fileName,types{i});
    % Get the slices' file names of both gray-level images 
    % and segmentation masks
    dirOut= dir(fullfile(strI,'*.jpg'));
    img = fullfile(strI,{dirOut.name}'); % Gray-level data
    dirOut= dir(fullfile(strM,'*.png'));
    msk = fullfile(strM,{dirOut.name}'); % Segmentation mask
    % Get image information
    info = imfinfo(img{1});
    % Number of slices in the DCE-MRI volume
    N = numel(img);
    % Initialize 3-D gray-level image and segmentation
    I = zeros(info.Height,info.Width,N,'uint8');
    B = false(info.Height,info.Width,N);
    for j = 1:N  
        I(:,:,j) = imread(img{j}); % Read gray-level slice
        B(:,:,j) = imread(msk{j}); % Read segmentation slice
    end
    % Crop the volume of interest
    [I,B] = cropVOI(I,B);
    % Isotropic resampling to a common resolution of 1x1x1 mm3
    I = isotropic_resampling(I,1,2.4,1);
    B = isotropic_resampling(B,1,2.4,1);
    % Save in a structure the volumes
    eval(sprintf('%s.Image=I;',varnames{i}));
    eval(sprintf('%s.Mask=B;',varnames{i}));
    % Determine the class label
    if contains(fileName,'-Be-')
        Y = 0; % Benign
    else
        Y = 1; % Mailgnant
    end
end

% Save MAT file
save(fullfile(pathOut,sprintf('%s.mat',fileName)),...
     'SUB1','SUB2','SUB3','SUB4','SUB5','SUB6','SUB7','SUB8',...
     'C0','C1','C2','C3','C4','C5','C6','C7','C8','Y');

% Shows a volume
volshow(C1.Image,'OverlayData',C1.Mask);